if (process.env.NODE_ENV === "production") {
    module.exports = { mongoURI: 'mongodb+srv://user:password@cluster0.wueyx.mongodb.net/motion?retryWrites=true&w=majority' }
} else {
    module.exports = { mongoURI: 'mongodb://localhost/motion' }
}
