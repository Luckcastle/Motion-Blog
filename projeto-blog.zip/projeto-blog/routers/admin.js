const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
require('../models/Categoria');
const Categoria = mongoose.model('Categorias');
require('../models/Postagem');
const Postagem = mongoose.model('Postagens');
const { eAdmin } = require('../helpers/eAdmin');



router.get('/', eAdmin, (req, res) => {
    res.render('admin/index')
});

router.get('/posts', eAdmin, (req, res) => {
    res.send('Página de posts')
});

router.get('/categorias', eAdmin, (req, res) => {
    Categoria.find().sort({ date: 'desc' }).then((categorias) => {
        res.render('admin/categorias', { categorias: categorias });
    }).catch((erro) => {
        req.flash('error_msg', 'erro ao listar categorias');
        res.redirect('/admin');
    })
});
router.get('/categorias/add', eAdmin, (req, res) => {
    res.render('admin/addcategorias');
});
// Rota cria categoria
router.post('/categorias/nova', eAdmin, (req, res) => {

    let erros = [];
    if (!req.body.nome || typeof req.body.nome === undefined || req.body.nome === null) {
        erros.push({ texto: 'Nome inválido' });
    }
    if (!req.body.slug || typeof req.body.slug === undefined || req.body.slug === null) {
        erros.push({ texto: 'Slug inválido' });
    }
    if (erros.length > 0) {
        res.render('admin/addcategorias', { erros: erros });
    } else {
        const novaCategoria = {
            nome: req.body.nome,
            slug: req.body.slug
        }

        new Categoria(novaCategoria).save().then(() => {
            req.flash("success_msg", "Categoria criada com sucesso");
            res.redirect('/admin/categorias');
        }).catch((err) => {
            req.flash("error_msg", "erro ao criar categoria");
            res.redirect('/admin');

        })
    }
});
// Rota edita categorias
router.get('/categorias/edit/:id', eAdmin, (req, res) => {
    Categoria.findOne({ _id: req.params.id }).then((categoria) => {
        req.flash('success_msg', 'Editada com sucesso!')
        res.render('admin/editcategorias', { categoria: categoria });
    }).catch((erro) => {
        req.flash("error_msg", "Categoria inexistente");
        res.redirect('/admin/categorias');
    })
})
router.post('/categorias/edit', eAdmin, (req, res) => {
    Categoria.findOne({ _id: req.body.id }).then((categoria) => {
        categoria.nome = req.body.nome;
        categoria.slug = req.body.slug;

        categoria.save().then(() => {
            req.flash('error_msg', 'Editado com sucesso!');
            res.redirect('/admin/categorias')
        }).catch((erro) => {
            req.flash('error_msg', 'Erro ao editar');
            res.redirect('/admin/categorias');
        })
    }).catch((erro) => {
        req.flash('error_msg', 'Erro ao editar');
        res.redirect('/admin/categorias');
    })
});
// Rota deleta categorias
router.post('/categorias/deletar', eAdmin, (req, res) => {
        Categoria.remove({ _id: req.body.id }).then(() => {
            req.flash('success_msg', 'Deletado com sucesso!');
            res.redirect('/admin/categorias');
        }).catch((erro) => {
            req.flash('error_msg', 'Erro ao deletar categoria');
            res.redirect('/admin/categorias');
        })
    })
    // Rota Lista Postagem
router.get('/postagens', eAdmin, (req, res) => {
    Postagem.find().populate('Categorias').sort({ data: 'desc' }).then((postagens) => {
        res.render('admin/postagens', { postagens: postagens })
    }).catch((erro) => {
        req.flash('error_msg', 'Erro ao listar postagens');
        res.redirect('/admin');
    })
});
//Rota Add postagem
router.get('/postagens/add', eAdmin, (req, res) => {
    Categoria.find().then((categorias) => {
        res.render('admin/addpostagem', { categorias: categorias });
    }).catch((erro) => {
        req.flash('error_msg', 'Erro ao carregar formulário');
        res.redirect('/admin');
    })
});
// Rota Adiciona postagem
router.post('/postagens/nova', eAdmin, (req, res) => {
    let erros = [];

    if (req.body.categoria == '0') {
        erros.push({ texto: 'Categoria inválida, adicione uma categoria!' })
    }
    if (erros.length > 0) {
        res.render('admin/postagem', { erros: erros })
    } else {
        const novaPostagem = {
            titulo: req.body.titulo,
            descricao: req.body.descricao,
            conteudo: req.body.conteudo,
            categoria: req.body.categoria,
            slug: req.body.slug
        }

        new Postagem(novaPostagem).save().then(() => {
            req.flash('success_msg', 'Postagem criada com sucesso!');
            res.redirect('/admin/postagens');
        }).catch((erro) => {
            req.flash('error_msg', 'Erro ao cadastrar postagem');
            res.redirect('/admin/postagens');
        })
    }
});
// Rota edita postagem
router.get('/postagens/edit/:id', eAdmin, (req, res) => {

    Postagem.findOne({ _id: req.params.id }).then((postagem) => {
        Categoria.find().then((categorias) => {
            res.render('admin/editpostagens', { categorias: categorias, postagem: postagem });
        }).catch((erro) => {
            req.flash('error_msg', 'Erro ao listar categorias!');
            res.redirect('/admin/postagens')
        })
    }).catch((erro) => {
        req.flash('error_msg', 'Erro ao carregar dados da postagem!');
        res.redirect('/admin/postagens');
    })
});

router.post('/postagem/edit', eAdmin, (req, res) => {
    Postagem.findOne({ _id: req.body.id }).then((postagem) => {
        postagem.titulo = req.body.titulo
        postagem.slug = req.body.slug
        postagem.descricao = req.body.descricao
        postagem.conteudo = req.body.conteudo
        postagem.categoria = req.body.categoria

        postagem.save().then(() => {
            req.flash('success_msg', 'Atualizado com sucesso!');
            res.redirect('/admin/postagens');
        }).catch((erro) => {
            req.flash('error_msg', 'Erro interno');
            res.redirect('/admin/postagens');
        });
    }).catch((erro) => {
        req.flash('error_msg', 'Não foi possível atualizar os dados! ')
        res.redirect('/admin/postagens');
    });
});

router.get('/postagens/deletar/:id', eAdmin, (req, res) => {
    Postagem.remove({ _id: req.params.id }).then(() => {
        req.flash('success_msg', 'Deletado com sucesso!')
        res.redirect('/admin/postagens');
    }).catch((erro) => {
        req.flash('error_msg', 'Não foi possível deletar a postagem!');
        res.redirect('/admin/postagens');
    })
})


module.exports = router;