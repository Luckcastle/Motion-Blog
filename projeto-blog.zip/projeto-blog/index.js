//==============================CARREGANDO MÓDULOS====================================
const express = require('express');
const app = express();
const handlebars = require('express-handlebars');
const bodyparser = require('body-parser');
const mongoose = require('mongoose');
const adminRouter = require('./routers/admin');
const path = require('path');
const session = require('express-session');
const flash = require('connect-flash');
require('./models/Postagem');
const Postagem = mongoose.model('Postagens');
require('./models/Categoria');
const Categoria = mongoose.model('Categorias');
const Usuarios = require('./routers/usuario');
const passport = require('passport');
require('./config/auth')(passport);
const db = require('./config/db');



//===============================CONFIGURAÇÕES==============================
// SESSÃO
app.use(session({
    secret: "Naits071",
    resave: true,
    saveUninitialized: true
}))

app.use(passport.initialize());
app.use(passport.session());

app.use(flash());

//MIDDLEWARE

app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    res.locals.user = req.user || null;
    next();
});



// BODY-PARSER
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());

// HANDLEBARS

app.engine('handlebars', handlebars({
    defaultLayout: 'main',
    runtimeOptions: {
        allowProtoPropertiesByDefault: true,
        allowProtoMethodsByDefault: true
    }
}));
app.set('view engine', 'handlebars');


// MONGOOSE
mongoose.Promise = global.Promise;
mongoose.connect(db.mongoURI, { useUnifiedTopology: true, useNewUrlParser: true, useCreateIndex: true }).then(() => {
    console.log('connection successfull');
}).catch((erro) => {
    console.log('Erro in connection' + erro);
});

// PUBLIC
app.use(express.static(path.join(__dirname, "public")));



//==================================ROTAS=======================================
app.get('/', (req, res) => {
    Postagem.find().populate('categoria').sort({ data: 'desc' }).then((postagens) => {
        res.render('index', { postagens: postagens });
    }).catch((erro) => {
        req.flash('error_msg', 'Erro interno');
        res.redirect('/404');
    })
});
app.get('/postagem/:slug', (req, res) => {
    Postagem.findOne({ slug: req.params.slug }).then((postagem) => {
        if (postagem) {
            res.render('postagem/index', { postagem: postagem })
        } else {
            req.flash('error_msg', 'Postagem inexistente!');
            res.redirect('/');
        }
    }).catch((erro) => {
        req.flash('error_msg', 'Erro interno');
        res.redirect('/');
    })
});

app.get('/categorias', (req, res) => {
    Categoria.find().then((categorias) => {
        res.render('categorias/index', { categorias: categorias })
    }).catch((erro) => {
        req.flash('error_msg', 'Erro interno');
        res.redirect('/')
    });
});

app.get('/categorias/:slug', (req, res) => {
    Categoria.findOne({ slug: req.params.slug }).then((categoria) => {
        if (categoria) {
            Postagem.find({ categoria: categoria._id }).then((postagens) => {
                res.render('categorias/postagens', { postagens: postagens, categoria: categoria })
            }).catch((erro) => {
                req.flash('error_msg', 'Não foi possível carregar as postagens!');
                res.redirect('/')
            })
        } else {
            req.flash('error_msg', 'Categoria inexistente!');
            res.redirect('/')
        }
    }).catch((erro) => {
        req.flash('error_msg', 'Erro, não foi possível carregar a página!');
        res.redirect('/')
    })
})

app.get('/404', (req, res) => {
    res.send('Erro 404');
})
app.get('/Postagens', (req, res) => {
    res.send('Lista de postagens');
});


app.use('/admin', adminRouter);
app.use('/usuarios', Usuarios);



//=================================OUTROS===================================
const PORT = process.env.PORT || 8081;
app.listen(PORT, () => {
    console.log('Server on in http://localhost:8081');
});