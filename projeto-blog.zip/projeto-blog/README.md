# Motion-Blog
Estrutura de um blog com cadastro de usuarios com sessões em nodejs-express-mongoDB

sera preciso adicionar a connection string no arquivo db.js na pasta config.
